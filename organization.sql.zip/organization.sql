-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июн 26 2022 г., 18:50
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `sniperz0_pot`
--

-- --------------------------------------------------------

--
-- Структура таблицы `organization`
--
-- Создание: Июн 26 2022 г., 14:35
-- Последнее обновление: Июн 26 2022 г., 15:34
--

DROP TABLE IF EXISTS `organization`;
CREATE TABLE `organization` (
  `id` int(11) NOT NULL,
  `full_name` varchar(64) NOT NULL,
  `abbreviated_name` varchar(64) NOT NULL,
  `date_registration` date DEFAULT NULL,
  `legal_address` varchar(64) NOT NULL,
  `postal_adress` varchar(64) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(64) NOT NULL,
  `director` varchar(64) NOT NULL,
  `inn` varchar(10) NOT NULL,
  `cat` varchar(10) NOT NULL,
  `okpo` varchar(8) NOT NULL,
  `is_actual` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `verefied` tinyint(1) NOT NULL,
  `uid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `organization`
--

INSERT INTO `organization` (`id`, `full_name`, `abbreviated_name`, `date_registration`, `legal_address`, `postal_adress`, `phone`, `email`, `director`, `inn`, `cat`, `okpo`, `is_actual`, `active`, `verefied`, `uid`) VALUES
(1, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"МОНТЕ\"', 'ООО \"МОНТЕ\"', NULL, '127015, город Москва, Вятская ул., д. 27 к. 5, чердак пом. VII, ', '127015, город Москва, Вятская ул., д. 27 к. 5, чердак пом. VII, ', '89889337354', 'monte@mail.ru', 'Саликов Олег Николаевич', '7724793050', '771401001', '92490041', 1, 1, 0, '558eb44e-03af-454c-bc3e-667c5dcb862b'),
(2, 'Общество с ограниченной Ответственностью \"Глобал фуд\"', 'ООО \"Глобал фуд\"', NULL, '450078, Республика Башкортостан, г. Уфа, Владивостокская ул., д.', '450078, Республика Башкортостан, г. Уфа, Владивостокская ул., д.', '+7 (917) 34', '', 'БАДИКОВ ТИМОФЕЙ ВЛАДИМИРОВИЧ', '0278202810', '027801001', '20828072', 1, 0, 0, '874b12ec-e293-4b22-8ba1-6ad6d5ed08b3'),
(7, 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"ВИЛОМИКС РУС\"', 'ООО \"ВИЛОМИКС\"', NULL, '125315, МОСКВА ГОРОД, ПР-КТ ЛЕНИНГРАДСКИЙ, Д. 80, К. 16, ПОМЕЩ. ', ' Г МОСКВА,УЛ САМОКАТНАЯ, Д 2А, КОРП 1', '+7 (495) 95', 'yusa@vilomix.ru', ' БАДИКОВ ТИМОФЕЙ ВЛАДИМИРОВИЧ', '7113016734', '774301001', '54539238', 1, 0, 0, '5611127b-5a2c-44e4-9ab5-171911549215');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inn` (`inn`),
  ADD UNIQUE KEY `uid` (`uid`),
  ADD UNIQUE KEY `organization_id_uindex` (`id`),
  ADD KEY `indx` (`id`) USING BTREE;

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `organization`
--
ALTER TABLE `organization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
