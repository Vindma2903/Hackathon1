import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: '[app-header]',
  templateUrl: './app-header.component.html',
})
export class AppHeader implements AfterViewInit {

  constructor(
  ) { }

  ngAfterViewInit()  {
	}

}
